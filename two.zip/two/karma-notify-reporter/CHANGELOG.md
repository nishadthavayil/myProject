## 1.0.1
- add message for disconnects and errors thrown

## 1.0.0
- upgrades to node-notifier to v4.5.0
