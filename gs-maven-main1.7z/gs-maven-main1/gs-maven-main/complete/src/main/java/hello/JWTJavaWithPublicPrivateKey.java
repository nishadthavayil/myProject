package hello;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JWTJavaWithPublicPrivateKey {

    public static void main(String[] args) {

    	String privateKeyString = "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQC3lcF7Ie+Qxs5E"+
    			"tvc6VgxSowZwkpMtluCzpVlIMjX9GiaivSf+ZuNwG6FZr7SlSLzIU2QiiuoYtIkz"+
    			"jazxlCZmmOHmZO8neQEqsXaw+kKf0K5sGQYPhdp6TZ36bdZtGT8ixvp51SeYnL8O"+
    			"NMNKuZwEWfWCTM3I33/+FKIfdrKqdhfFm/JvrDO1MwAJj24qODYDElkU0idLb/9v"+
    			"49T3/3DbEXYugZB4GUHphIDIh5nEupkNjxWE+gcjVhrRiL7xQ/uD7N3Cmkh0rxyU"+
    			"0pq9tJuO6SBGa41U7jaODl2RzNP4Ot1QfhCTn/eaSN5EUmgWpA22t/wm7FXavVZi"+
    			"UfWKk9yXAgMBAAECggEANZt8OPlq3ArBdp06ygUQah0Cp2KVqY1SJgMVdBh9XWAC"+
    			"gijcAdSHe1gGIItHI7B+t7xqFBAeVYJ6QdyP8KcDI5hm9oDouM0DwzS45OrfA43L"+
    			"MPOJqoS6jFYX2GW0ZH0ny37w6xyMCGtU+s/7atmSLk8aeqb0vEBPPqFFygw+FboR"+
    			"Nk18hiCSmFHESOlgL5O7dHJFwi5myM2/jfogKZl/AnTMlAOyvpgMZEtwWaELaQSu"+
    			"kDVN3p/aSs1kNs7VU1L+2VD5ciXz4vLcZPg9tI879lx0ab8g2Bwy6ZTc0LeipTN8"+
    			"53srXDPuBI7P+s0Kcl1aOJym7LBr4YJ8/XnKgrsRcQKBgQDppc/3iKnPU2e5r718"+
    			"hzipvUSR5o3FNwt0dY13Ui46ZV8H7BnBFv3665eVgcIp1exM7Cvnfet6bcj750vy"+
    			"bx8+xlGHzPEhdZIXfcMLPh8WHI0XKkzxdJ56EGdCYT8qqHXljKeIQkHUFnIrNQ2s"+
    			"Wxb7bdcKbfnBijp5xlnqLlYoXwKBgQDJJd/Eb3uG0QHppqZpwGAvQifN1iYw8T5f"+
    			"c7oCyxPPTv/N2wXI9E/0/49L7Q7q9lzdNTpFbN/nhLcZKP1Lnd7FpU1/MzDPcaOh"+
    			"XXhSa633xh9ED4LPTveiMbMqywp6u/ncJ6GS/OZo2yQGqLtVH7WELcqfs708mdcX"+
    			"aoC7qkoWyQKBgQDSL4PinmKES/enp1zCxbJHoCgrSEiI/XekkItup9NGXSMcMV0J"+
    			"wvE/5Og8arqMgBFPMbZdTX2kaVbApdZAhY6KHkYB8G+LNgTydQQc/QliDtUt3bPS"+
    			"EqLuFAuQP4NfkKRemCWuAkzNylNyYwul3VvTW4BztXNUlFD+c103ue9v6QKBgQCn"+
    			"7snqG1UbEkYxhyOqaKUk72uB6wdJly+Gy3yBtoAcdQ0WFYS36FkU54QAVLM+sV6I"+
    			"hFbY/XPVu7SN+e23At+pTT/tMZTPrEV7hCjfTu0YTr1tujFw2LHgJPQ7hvaBz4xk"+
    			"JGY97IyFAGgMczSrdeS6rOxc9tfHz3yHHTDK/PoMGQKBgQDDz1HnF91foVhabORd"+
    			"TGhNZx4fxdTQLYGFY5IM4jRlKbx9yP/lZ1Bx5+7/Qv5VKCWhh1xVp5WBLtY1b+zS"+
    			"gExi68gEXlzrbfd4liIXKJU+4af5/7xjiAF6Cdt9tp1q4jvTpBJzokBVUdqxtygc"+
    			"+HK1vT3OQ2k5u3o5jEFqHUIQMg==";
    	
    	
    	String publickeyString ="MIIDTzCCAjcCAQAwgZgxCzAJBgNVBAYTAkFVMQwwCgYDVQQIDANWSUMxEjAQBgNV"+
    			"BAcMCU1lbGJvdXJuZTEmMCQGA1UECgwdRk9YVEVMIE1BTkFHRU1FTlQgUFRZIExJ"+
    			"TUlURUQxHTAbBgNVBAsMFEluZm9ybWF0aW9uIFNlcnZpY2VzMSAwHgYDVQQDDBdj"+
    			"dS1hbS5zbXMuZm94dGVsLmNvbS5hdTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC"+
    			"AQoCggEBALeVwXsh75DGzkS29zpWDFKjBnCSky2W4LOlWUgyNf0aJqK9J/5m43Ab"+
    			"oVmvtKVIvMhTZCKK6hi0iTONrPGUJmaY4eZk7yd5ASqxdrD6Qp/QrmwZBg+F2npN"+
    			"nfpt1m0ZPyLG+nnVJ5icvw40w0q5nARZ9YJMzcjff/4Uoh92sqp2F8Wb8m+sM7Uz"+
    			"AAmPbio4NgMSWRTSJ0tv/2/j1Pf/cNsRdi6BkHgZQemEgMiHmcS6mQ2PFYT6ByNW"+
    			"GtGIvvFD+4Ps3cKaSHSvHJTSmr20m47pIEZrjVTuNo4OXZHM0/g63VB+EJOf95pI"+
    			"3kRSaBakDba3/CbsVdq9VmJR9YqT3JcCAwEAAaBxMG8GCSqGSIb3DQEJDjFiMGAw"+
    			"EQYJYIZIAYb4QgEBBAQDAgZAMBMGA1UdJQQMMAoGCCsGAQUFBwMBMAsGA1UdDwQE"+
    			"AwIFoDApBgNVHREEIjAgghdjdS1hbS5zbXMuZm94dGVsLmNvbS5hdYIFY3UtYW0w"+
    			"DQYJKoZIhvcNAQELBQADggEBAJD3xMgDjN84y6sxw8oGHcIbtERDH3pmHTfsG22+"+
    			"AVyoRCfKnB3EiQS5t8QJwPXKAHDwXfZtA5PnDOVCMIaDIknyAemIgBt7Aq1hGTMf"+
    			"jgGYx3Scn0yjNI1t7qZbL45UKgzoeWkNAbBX1KANrs1KoWGojGi/kPF62FZcmykg"+
    			"HQ5ILOaOXWgouC0Pwqd5R5WmMR+4jA87+7pphN6ETEmGJfFYyfc630waoDuOgFqB"+
    			"cFjH/o3cv/hEL37xxAdDGQNw+RoiA8iNN7Ax3ZpR4wzuTaiRhXSOqdKYtk/SryEo"+
    			"GImU1/bAnqFmTfjjD7NEVGdRO5+a04ZLHxi8l3iFRI6stXk=";
    	
    	
    	
    	byte[] b1 = Base64.getDecoder().decode(privateKeyString); 
    	PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(b1); 
    	
    	byte[] b2 = Base64.getDecoder().decode(publickeyString); 
    	X509EncodedKeySpec spec2 = new X509EncodedKeySpec(Base64.getDecoder().decode(publickeyString));
    	
    	KeyFactory kf = null;
		try {
			kf = KeyFactory.getInstance("RSA");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		PrivateKey privateKey = null;
		PublicKey  publickey = null;
    	try {
			privateKey = kf.generatePrivate(spec);
			publickey = kf.generatePublic(spec2);
		} catch (InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	System.out.println("privateKey::"+privateKey);
    	generateToken(privateKey);
    	
    	System.out.println("privateKey::"+publickey);
    }

    @SuppressWarnings("deprecation")
	public static String generateToken(PrivateKey privateKey) {
        String token = null;
        try {
            Map<String, Object> claims = new HashMap<String, Object>();

            // put your information into claim
            claims.put("id", "xxx");
            claims.put("role", "user");
            claims.put("created", new Date());

            token = Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.RS512, privateKey).compact();
            System.out.println("new token::"+token); 

        } catch (Exception e) {
            e.printStackTrace();
        }
        return token;
    }

    // verify and get claims using public key

    private static Claims verifyToken(String token, PublicKey publicKey) {
        Claims claims;
        try {
            claims = Jwts.parser().setSigningKey(publicKey).parseClaimsJws(token).getBody();

            System.out.println(claims.get("id"));
            System.out.println(claims.get("role"));

        } catch (Exception e) {

            claims = null;
        }
        return claims;
    }

    // Get RSA keys. Uses key size of 2048.
    private static Map<String, Object> getRSAKeys() throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        PrivateKey privateKey = keyPair.getPrivate();
        PublicKey publicKey = keyPair.getPublic();
        Map<String, Object> keys = new HashMap<String, Object>();
        keys.put("private", privateKey);
        keys.put("public", publicKey);
        return keys;
    }
}