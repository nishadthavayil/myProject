package hello;

import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String jwt = "eyJhbGciOiJSUzI1NiJ9.eyJuYW1lIjoiSmFuZSBEb2UiLCJlbWFpbCI6ImphbmVAZXhhbXBsZS5jb20iLCJzdWIiOiJqYW5lIiwianRpIjoiMzRkNzY1MzUtOWQ4OC00YjdiLTgxOTQtZjQyYmJiNmRmY2NhIiwiaWF0IjoxNjYzMzM5MjQ1LCJleHAiOjE2NjMzMzk1NDV9.ZaYXzW9s9zyKpvNlKd-lCCRwyr7sx9LvoaN10-l6TfA-kejRey3LA2F4tmI3dCsUXYWdB926zKfj8_Zj9MxnA2YTLtFFR_U2EQbiSxxGpZhyTe8hsjjhj9fehODkU6vMZDa6zJuO3S7ae4KC015gjWs2VtQcQb1z87-GEon5-Katstrwv0JqpcrykwQbASOC4EHwqHwxOwacWUAtCOxEgHXzNFh3GnqVnl8oUoY0BYXKFXf25mni-Fk6pnydud2Tm4CkPQ_Hj1WLGv0q2gUTOR2VlpSXd1cLZdWUdjSKSNQGAH9s2JwdbC9ng9weJmmKXj4Xhvksoe0cLEVOWl0cIQ";

		String signedData = jwt.substring(0, jwt.lastIndexOf("."));
		 String signatureB64u = jwt.substring(jwt.lastIndexOf(".")+1,jwt.length());
        byte signature[] = Base64.getUrlDecoder().decode(signatureB64u);
        
        
        String rsaPublicKey = "-----BEGIN CERTIFICATE-----" +
    			"MIIGUjCCBTqgAwIBAgITEgBQ+WNMka/urWvcRwAAAFD5YzANBgkqhkiG9w0BAQsF" +
    			"ADB2MRIwEAYKCZImiZPyLGQBGRYCYXUxEzARBgoJkiaJk/IsZAEZFgNjb20xFjAU" +
    			"BgoJkiaJk/IsZAEZFgZmb3h0ZWwxEzARBgoJkiaJk/IsZAEZFgNlbnQxHjAcBgNV" +
    			"BAMTFUZveHRlbCBDb3JwIFN1YjEgLSBHMjAeFw0yMjA5MTUwMTI4MzZaFw0yNTA5" +
    			"MTQwMTI4MzZaMIGYMQswCQYDVQQGEwJBVTEMMAoGA1UECBMDVklDMRIwEAYDVQQH" +
    			"EwlNZWxib3VybmUxJjAkBgNVBAoTHUZPWFRFTCBNQU5BR0VNRU5UIFBUWSBMSU1J" +
    			"VEVEMR0wGwYDVQQLExRJbmZvcm1hdGlvbiBTZXJ2aWNlczEgMB4GA1UEAxMXY3Ut" +
    			"YW0uc21zLmZveHRlbC5jb20uYXUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK" +
    			"AoIBAQC3lcF7Ie+Qxs5Etvc6VgxSowZwkpMtluCzpVlIMjX9GiaivSf+ZuNwG6FZ" +
    			"r7SlSLzIU2QiiuoYtIkzjazxlCZmmOHmZO8neQEqsXaw+kKf0K5sGQYPhdp6TZ36" +
    			"bdZtGT8ixvp51SeYnL8ONMNKuZwEWfWCTM3I33/+FKIfdrKqdhfFm/JvrDO1MwAJ" +
    			"j24qODYDElkU0idLb/9v49T3/3DbEXYugZB4GUHphIDIh5nEupkNjxWE+gcjVhrR" +
    			"iL7xQ/uD7N3Cmkh0rxyU0pq9tJuO6SBGa41U7jaODl2RzNP4Ot1QfhCTn/eaSN5E" +
    			"UmgWpA22t/wm7FXavVZiUfWKk9yXAgMBAAGjggK0MIICsDATBgNVHSUEDDAKBggr" +
    			"BgEFBQcDATALBgNVHQ8EBAMCBaAwKQYDVR0RBCIwIIIXY3UtYW0uc21zLmZveHRl" +
    			"bC5jb20uYXWCBWN1LWFtMB0GA1UdDgQWBBSo9fL9KhL0IvSIz9ltgK0gC8JyezAf" +
    			"BgNVHSMEGDAWgBSIbMbscX+60cSKdfLHkSwtsqJlBDCB6AYDVR0fBIHgMIHdMIHa" +
    			"oIHXoIHUhoHRbGRhcDovLy9DTj1Gb3h0ZWwlMjBDb3JwJTIwU3ViMSUyMC0lMjBH" +
    			"MixDTj1TWURDQVMxMSxDTj1DRFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMs" +
    			"Q049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1lbnQsREM9Zm94dGVsLERD" +
    			"PWNvbSxEQz1hdT9jZXJ0aWZpY2F0ZVJldm9jYXRpb25MaXN0P2Jhc2U/b2JqZWN0" +
    			"Q2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnQwgdsGCCsGAQUFBwEBBIHOMIHLMIHI" +
    			"BggrBgEFBQcwAoaBu2xkYXA6Ly8vQ049Rm94dGVsJTIwQ29ycCUyMFN1YjElMjAt" +
    			"JTIwRzIsQ049QUlBLENOPVB1YmxpYyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZp" +
    			"Y2VzLENOPUNvbmZpZ3VyYXRpb24sREM9ZW50LERDPWZveHRlbCxEQz1jb20sREM9" +
    			"YXU/Y0FDZXJ0aWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNlcnRpZmljYXRpb25B" +
    			"dXRob3JpdHkwOwYJKwYBBAGCNxUHBC4wLAYkKwYBBAGCNxUIhajlOYfUAoT9nR+G" +
    			"tv1ig+zkXgaH6foi04MVAgFkAgEKMBsGCSsGAQQBgjcVCgQOMAwwCgYIKwYBBQUH" +
    			"AwEwDQYJKoZIhvcNAQELBQADggEBAEHQyovxovhEgXXSYQlllNtY+QAySl5DTwQA" +
    			"jSKPUJ5c+fyAQ8JzZ1ox7/5tP/TU2xDNFRx4zQmwOZFnVqbP8MWLp/r3GnEQrrVT" +
    			"9LU3Z50O6H3D40EZg2tVbsfvj+qF23ZLCLQMdzwpQU+ayo+wYFwKQJs/vhAAy8Ys" +
    			"QZi0r3NfWg6HqmsE5EsPU1n+2s8g0nAcdIX5TCcO8rOgnJiDtEqcyPFC34vGeHxH" +
    			"mA6Ph/0xSSDo1PuFoS5ndfAhAj+jvL52gOGFiRpgOewVd1CkG5n5+lKTJlXN81La" +
    			"0/zljpoDxF2NfdKBTfCg2QfRrm9YNTQ2kZ+cbVJnfxtbUY2RJOQ=" +
    			"-----END CERTIFICATE-----";
    	
    	
        rsaPublicKey = rsaPublicKey.replace("-----BEGIN CERTIFICATE-----", "");
        rsaPublicKey = rsaPublicKey.replace("-----END CERTIFICATE-----", "");
        
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(rsaPublicKey));
        KeyFactory kf;
		try {
			kf = KeyFactory.getInstance("RSA");
			
			  PublicKey publicKey = kf.generatePublic(keySpec);
		        
		        
		        Signature sig = Signature.getInstance("SHA256withRSA");
		        sig.initVerify(publicKey);
		        sig.update(signedData.getBytes());
		        boolean isVerify = sig.verify(signature);
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | InvalidKeyException | SignatureException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      

	}

}
