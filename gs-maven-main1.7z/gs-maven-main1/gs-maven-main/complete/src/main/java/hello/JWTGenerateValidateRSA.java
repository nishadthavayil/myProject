package hello;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;
public class JWTGenerateValidateRSA {

	public static void main(String[] args) throws InvalidKeySpecException, NoSuchAlgorithmException {

        //String jwt = createJwtSignedHMAC();
        
		String jwt="eyJ0eXAiOiJKV1QiLCJraWQiOiJuZUFOQ3NNeVlmRUlWbW5ycFkzV2hKUjQ3MkU9IiwiYWxnIjoiUlMyNTYifQ.eyJhdF9oYXNoIjoia09CUmJkRXN1a0lKM0tmVzZLeGw0QSIsInN1YiI6IlI5TTlJWWJpN3hDZURFeEsrUjRWTndRUUxJZFZmcGtCaUw1N1VsMXFhaUE9IiwiYXVkaXRUcmFja2luZ0lkIjoiMGVlNDZjNzYtZTQzYy00ZDcwLWE1MDgtNDdkNTAyYzZkYjVlLTI5OTQyIiwiaXNzIjoiaHR0cHM6Ly93d3ctdWF0NC5hd3MuZm94dGVsLmNvbS5hdTo0NDMvb3BlbmFtL29hdXRoMiIsInRva2VuTmFtZSI6ImlkX3Rva2VuIiwiZWxpZ2liaWxpdHkiOlt7ImFjY291bnRJZCI6IjE1ODYwNDk3IiwiZWxpZ2libGUiOmZhbHNlLCJzdGF0dXMiOiJBQ1RJVkUifV0sIm5vbmNlIjoiaDN4dTd5IiwiYXVkIjoiRjFhcHAiLCJjX2hhc2giOiJkVFFPTm81MnBzWDBEdlhOdVZERlBBIiwiYWNyIjoiMCIsIm9yZy5mb3JnZXJvY2sub3BlbmlkY29ubmVjdC5vcHMiOiJqeGNlZUxmQ3o2S1pWV21xT2poNklDUGwzaWsiLCJhenAiOiJGMWFwcCIsImF1dGhfdGltZSI6MTY2MzMyNjUzMywicmVhbG0iOiIvZXh0ZXJuYWwiLCJleHAiOjE2NjMzMzAyODUsInRva2VuVHlwZSI6IkpXVFRva2VuIiwiaWF0IjoxNjYzMzI2Njg1fQ.Fi_ySdsToWp2PuipPU2PVST_jhO5GBwtSFNw2XxpNXvpWsNsUh_ftTvc7EJsCt4wYOGnJ0B-idv6Ku608w2jU_Hr6ECNu-nd9hLa9mKv4eumLQJmpUtygVxAB7svcx53Bu74uXrU_DLNAELp5n0eYLf3kmJ8mWvRF0972G2_bJ62UdJnetI2LLA4iutTgvm9ORmIm5Nk4OpyW88Jt7p5xl99_HWZQ8ek-2E3AebJV6AQ8KDEwFxBcK7QObYkFrVrKtoM0olnlTidow3gu2xv07vMuUZ20ffISi777DkaLeQ0PEE1a1P9voY7rc8k-WicKyYcHf3_JzhPo9UupJ0UZg";
		System.out.println("jwt is:"+jwt);
		
		

        Jws<Claims> token = parseJwt(jwt);

        System.out.println(token.getBody());
    }

    public static Jws<Claims> parseJwt(String jwtString) throws InvalidKeySpecException, NoSuchAlgorithmException {

        PublicKey publicKey = getPublicKey();

        Jws<Claims> jwt = Jwts.parserBuilder()
                .setSigningKey(publicKey)
                .build()
                .parseClaimsJws(jwtString);

        return jwt;
    }


    public static String createJwtSignedHMAC() throws InvalidKeySpecException, NoSuchAlgorithmException {

        PrivateKey privateKey = getPrivateKey();
        

        Instant now = Instant.now();
        String jwtToken = Jwts.builder()
                .claim("name", "Jane Doe")
                .claim("email", "jane@example.com")
                .setSubject("jane")
                .setId(UUID.randomUUID().toString())
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(now.plus(5l, ChronoUnit.MINUTES)))
                .signWith(privateKey)
                .compact();

        return jwtToken;
    }


    private static PublicKey getPublicKey() throws NoSuchAlgorithmException, InvalidKeySpecException {
       /* String rsaPublicKey = "-----BEGIN PUBLIC KEY-----" +
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyu3NB7Tr3nzETLNbZHYi" +
                "ZvgNeg3/OZUJZl40LzBzYGOD/8575eJETjfQ3QXaNyvNThu6Uf9B/V73QUxKI4/+" +
                "rwlbjA3niIga4MdDiY4b9K/KFA+HedvtZF1yE2p4smXGydPLOLBe31EgriGTob78" +
                "EE3f7SMFxlNaqn4Pm7KJkOodnMz0ilwLseeL1IkTtiFn/2OrcMpPHMtTxyDn3pQl" +
                "VCeJM5j/grDh+0YdyTMGdDHOBgM53VqSsDVyo1TNtP2yhPRYCIiI85hEHVaUnVM9" +
                "jGwCjNZLJHWh10Mrmh6B3z8BEmLhMAZXeL4fQBjBd42DLvIIJwM1USKFhjK+XghN" +
                "rQIDAQAB" +
                "-----END PUBLIC KEY-----";*/
    	
    	String rsaPublicKey = "-----BEGIN PUBLIC KEY-----" +
    			"MIIGUjCCBTqgAwIBAgITEgBQ+WNMka/urWvcRwAAAFD5YzANBgkqhkiG9w0BAQsF" +
    			"ADB2MRIwEAYKCZImiZPyLGQBGRYCYXUxEzARBgoJkiaJk/IsZAEZFgNjb20xFjAU" +
    			"BgoJkiaJk/IsZAEZFgZmb3h0ZWwxEzARBgoJkiaJk/IsZAEZFgNlbnQxHjAcBgNV" +
    			"BAMTFUZveHRlbCBDb3JwIFN1YjEgLSBHMjAeFw0yMjA5MTUwMTI4MzZaFw0yNTA5" +
    			"MTQwMTI4MzZaMIGYMQswCQYDVQQGEwJBVTEMMAoGA1UECBMDVklDMRIwEAYDVQQH" +
    			"EwlNZWxib3VybmUxJjAkBgNVBAoTHUZPWFRFTCBNQU5BR0VNRU5UIFBUWSBMSU1J" +
    			"VEVEMR0wGwYDVQQLExRJbmZvcm1hdGlvbiBTZXJ2aWNlczEgMB4GA1UEAxMXY3Ut" +
    			"YW0uc21zLmZveHRlbC5jb20uYXUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK" +
    			"AoIBAQC3lcF7Ie+Qxs5Etvc6VgxSowZwkpMtluCzpVlIMjX9GiaivSf+ZuNwG6FZ" +
    			"r7SlSLzIU2QiiuoYtIkzjazxlCZmmOHmZO8neQEqsXaw+kKf0K5sGQYPhdp6TZ36" +
    			"bdZtGT8ixvp51SeYnL8ONMNKuZwEWfWCTM3I33/+FKIfdrKqdhfFm/JvrDO1MwAJ" +
    			"j24qODYDElkU0idLb/9v49T3/3DbEXYugZB4GUHphIDIh5nEupkNjxWE+gcjVhrR" +
    			"iL7xQ/uD7N3Cmkh0rxyU0pq9tJuO6SBGa41U7jaODl2RzNP4Ot1QfhCTn/eaSN5E" +
    			"UmgWpA22t/wm7FXavVZiUfWKk9yXAgMBAAGjggK0MIICsDATBgNVHSUEDDAKBggr" +
    			"BgEFBQcDATALBgNVHQ8EBAMCBaAwKQYDVR0RBCIwIIIXY3UtYW0uc21zLmZveHRl" +
    			"bC5jb20uYXWCBWN1LWFtMB0GA1UdDgQWBBSo9fL9KhL0IvSIz9ltgK0gC8JyezAf" +
    			"BgNVHSMEGDAWgBSIbMbscX+60cSKdfLHkSwtsqJlBDCB6AYDVR0fBIHgMIHdMIHa" +
    			"oIHXoIHUhoHRbGRhcDovLy9DTj1Gb3h0ZWwlMjBDb3JwJTIwU3ViMSUyMC0lMjBH" +
    			"MixDTj1TWURDQVMxMSxDTj1DRFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMs" +
    			"Q049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1lbnQsREM9Zm94dGVsLERD" +
    			"PWNvbSxEQz1hdT9jZXJ0aWZpY2F0ZVJldm9jYXRpb25MaXN0P2Jhc2U/b2JqZWN0" +
    			"Q2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnQwgdsGCCsGAQUFBwEBBIHOMIHLMIHI" +
    			"BggrBgEFBQcwAoaBu2xkYXA6Ly8vQ049Rm94dGVsJTIwQ29ycCUyMFN1YjElMjAt" +
    			"JTIwRzIsQ049QUlBLENOPVB1YmxpYyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZp" +
    			"Y2VzLENOPUNvbmZpZ3VyYXRpb24sREM9ZW50LERDPWZveHRlbCxEQz1jb20sREM9" +
    			"YXU/Y0FDZXJ0aWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNlcnRpZmljYXRpb25B" +
    			"dXRob3JpdHkwOwYJKwYBBAGCNxUHBC4wLAYkKwYBBAGCNxUIhajlOYfUAoT9nR+G" +
    			"tv1ig+zkXgaH6foi04MVAgFkAgEKMBsGCSsGAQQBgjcVCgQOMAwwCgYIKwYBBQUH" +
    			"AwEwDQYJKoZIhvcNAQELBQADggEBAEHQyovxovhEgXXSYQlllNtY+QAySl5DTwQA" +
    			"jSKPUJ5c+fyAQ8JzZ1ox7/5tP/TU2xDNFRx4zQmwOZFnVqbP8MWLp/r3GnEQrrVT" +
    			"9LU3Z50O6H3D40EZg2tVbsfvj+qF23ZLCLQMdzwpQU+ayo+wYFwKQJs/vhAAy8Ys" +
    			"QZi0r3NfWg6HqmsE5EsPU1n+2s8g0nAcdIX5TCcO8rOgnJiDtEqcyPFC34vGeHxH" +
    			"mA6Ph/0xSSDo1PuFoS5ndfAhAj+jvL52gOGFiRpgOewVd1CkG5n5+lKTJlXN81La" +
    			"0/zljpoDxF2NfdKBTfCg2QfRrm9YNTQ2kZ+cbVJnfxtbUY2RJOQ=" +
    			"-----END PUBLIC KEY-----";
    	
    	
        rsaPublicKey = rsaPublicKey.replace("-----BEGIN PUBLIC KEY-----", "");
        rsaPublicKey = rsaPublicKey.replace("-----END PUBLIC KEY-----", "");
        System.out.println("replace:"+rsaPublicKey);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(rsaPublicKey));
        System.out.println("decode:"+keySpec);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        System.out.println("kf:"+kf);
        PublicKey publicKey = kf.generatePublic(keySpec);
        System.out.println("before ret:"+publicKey);
        return publicKey;
    }

    private static PrivateKey getPrivateKey() throws NoSuchAlgorithmException, InvalidKeySpecException {
        String rsaPrivateKey = "-----BEGIN PRIVATE KEY-----" +
                "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDK7c0HtOvefMRM" +
                "s1tkdiJm+A16Df85lQlmXjQvMHNgY4P/znvl4kRON9DdBdo3K81OG7pR/0H9XvdB" +
                "TEojj/6vCVuMDeeIiBrgx0OJjhv0r8oUD4d52+1kXXITaniyZcbJ08s4sF7fUSCu" +
                "IZOhvvwQTd/tIwXGU1qqfg+bsomQ6h2czPSKXAux54vUiRO2IWf/Y6twyk8cy1PH" +
                "IOfelCVUJ4kzmP+CsOH7Rh3JMwZ0Mc4GAzndWpKwNXKjVM20/bKE9FgIiIjzmEQd" +
                "VpSdUz2MbAKM1kskdaHXQyuaHoHfPwESYuEwBld4vh9AGMF3jYMu8ggnAzVRIoWG" +
                "Mr5eCE2tAgMBAAECggEBAKBPXiKRdahMzlJ9elyRyrmnihX7Cr41k7hwAS+qSetC" +
                "kpu6RjykFCvqgjCpF+tvyf/DfdybF0mPBStrlkIj1iH29YBd16QPSZR7NkprnoAd" +
                "gzl3zyGgcRhRjfXyrajZKEJ281s0Ua5/i56kXdlwY/aJXrYabcxwOvbnIXNxhqWY" +
                "NSejZn75fcacSyvaueRO6NqxmCTBG2IO4FDc/xGzsyFKIOVYS+B4o/ktUOlU3Kbf" +
                "vwtz7U5GAh9mpFF+Dkr77Kv3i2aQUonja6is7X3JlA93dPu4JDWK8jrhgdZqY9p9" +
                "Q8odbKYUaBV8Z8CnNgz2zaNQinshzwOeGfFlsd6H7SECgYEA7ScsDCL7omoXj4lV" +
                "Mt9RkWp6wQ8WDu5M+OCDrcM1/lfyta2wf7+9hv7iDb+FwQnWO3W7eFngYUTwSw5x" +
                "YP2uvOL5qbe7YntKI4Q9gHgUd4XdRJJSIdcoY9/d1pavkYwOGk7KsUrmSeoJJ2Jg" +
                "54ypVzZlVRkcHjuwiiXKvHwj2+UCgYEA2w5YvWSujExREmue0BOXtypOPgxuolZY" +
                "pS5LnuAr4rvrZakE8I4sdYjh0yLZ6qXJHzVlxW3DhTqhcrhTLhd54YDogy2IT2ff" +
                "0GzAV0kX+nz+mRhw0/u+Yw6h0QuzH9Q04Wg3T/u/K9+rG335j/RU1Tnh7nxetfGb" +
                "EwJ1oOqcXikCgYEAqBAWmxM/mL3urH36ru6r842uKJr0WuhuDAGvz7iDzxesnSvV" +
                "5PKQ8dY3hN6xfzflZoXssUGgTc55K/e0SbP93UZNAAWA+i29QKY6n4x5lKp9QFch" +
                "dXHw4baIk8Z97Xt/kw07f6FAyijdC9ggLHf2miOmdEQzNQm/9mcJ4cFn+DECgYEA" +
                "gvOepQntNr3gsUxY0jcEOWE3COzRroZD0+tLFZ0ZXx/L5ygVZeD4PwMnTNrGvvmA" +
                "tAFt54pomdqk7Tm3sBQkrmQrm0+67w0/xQ9eJE/z37CdWtQ7jt4twHXc0mVWHa70" +
                "NdPhTRVIAWhil7rFWANOO3Gw2KrMy6O1erW7sAjQlZECgYBmjXWzgasT7JcHrP72" +
                "fqrEx4cg/jQFNlqODNb515tfXSBBoAFiaxWJK3Uh/60/I6cFL/Qoner4trNDWSNo" +
                "YENBqXLZnWGfIo0vAIgniJ6OD67+1hEQtbenhSfeE8Hou2BnFOTajUxmYgGm3+hx" +
                "h8TPOvfHATdiwIm7Qu76gHhpzQ==" +
                "-----END PRIVATE KEY-----";
         
        rsaPrivateKey = rsaPrivateKey.replace("-----BEGIN PRIVATE KEY-----", "");
        rsaPrivateKey = rsaPrivateKey.replace("-----END PRIVATE KEY-----", "");

        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(rsaPrivateKey));
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey privKey = kf.generatePrivate(keySpec);
        return privKey;
    }
}
