package hello;

import io.jsonwebtoken.Jwts;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import io.jsonwebtoken.SignatureAlgorithm;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Base64;

public class CreateJWT {
	
	// without signing JWT
	/*public static void main(String args[]){
		
		Date date=new Date();
	    Calendar calendar = Calendar.getInstance();
	    date=calendar.getTime(); 
	    SimpleDateFormat s;
	    s=new SimpleDateFormat("MM/dd/yy");
		
		String jwtToken = Jwts.builder()
		        .claim("name", "Jane Doe")
		        .claim("email", "jane@example.com")
		        .setSubject("jane")
		        .setId(UUID.randomUUID().toString())
		        .setIssuedAt(Date.from(Instant.ofEpochSecond(1466796822L)))
		        // Sat Jun 24 2116 15:33:42 GMT-0400 (EDT)
		        .setExpiration(Date.from(Instant.ofEpochSecond(4622470422L)))
		        .compact();
		
		System.out.println(jwtToken);
	}*/
	
	
public static void main(String args[]){
		
	String secret = "asdfSFS34wfsdfsdfSDSD32dfsddDDerQSNCK34SOWEK5354fdgdf4";

	Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(secret), 
	                            SignatureAlgorithm.HS256.getJcaName());

	Instant now = Instant.now();
	String jwtToken = Jwts.builder()
	        .claim("name", "Jane Doe")
	        .claim("email", "jane@example.com")
	        .setSubject("jane")
	        .setId(UUID.randomUUID().toString())
	        .setIssuedAt(Date.from(now))
	        .setExpiration(Date.from(now.plus(5l, ChronoUnit.MINUTES)))
	        .signWith(hmacKey)
	        .compact();
	System.out.println(jwtToken);
	}



}
